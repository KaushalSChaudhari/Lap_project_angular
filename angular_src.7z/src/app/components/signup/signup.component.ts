import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  signupForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private router: Router
  ) {
    this.signupForm = this.fb.group({
      username: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9@_.-]+$')]],
      fullName: ['', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      gender: ['', Validators.required],
      city: ['', Validators.required],
      bloodGroup: ['', Validators.required],
      height: ['', [Validators.required, this.positiveNumberValidator]],
      weight: ['', [Validators.required, this.positiveNumberValidator]],
      password: ['', [Validators.required, Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$')]],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordMatchValidator });
  }

  // Custom Validator for Positive Numbers (Height & Weight)
  positiveNumberValidator(control: AbstractControl) {
    const value = control.value;
    return value >= 0 ? null : { nonPositive: true };
  }

  // Custom Validator to Ensure Password & Confirm Password Match
  passwordMatchValidator(form: AbstractControl) {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { passwordMismatch: true };
  }

  onSubmit() {
    if (this.signupForm.valid) {
      alert("Signup Successful! Redirecting to login page...");
      this.router.navigate(['/login']); // Redirect to Login Page
    }
  }
}
