import { Component } from '@angular/core';

@Component({
  selector: 'app-home', // This is the component's selector (used in templates if needed)
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  // Add any logic or properties specific to the home page here (if needed).
}