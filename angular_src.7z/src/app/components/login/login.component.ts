import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm: FormGroup;
  defaultEmail = 'user@gmail.com';
  defaultPassword = 'User@1234';

  constructor(private fb: FormBuilder, private router: Router) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]], // Initialize as empty
      password: ['', [Validators.required]] // Initialize as empty
    });
  }

  onSubmit() {
    const { email, password } = this.loginForm.value;

    // Check if entered email and password match default credentials
    if (email === this.defaultEmail && password === this.defaultPassword) {
      alert('Login Successful! Redirecting to home page...');
      this.router.navigate(['/']); // Redirect to Home Page
    } else {
      alert('Invalid credentials! Please try again.');
    }
  }
}
